<?php

namespace %NAMESPACE%\Controller;

class SiteController
{
    public function indexAction()
    {
        // your code here...
    }
}
