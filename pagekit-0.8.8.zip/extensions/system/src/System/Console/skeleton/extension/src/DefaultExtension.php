<?php

namespace %NAMESPACE%;

use Pagekit\Framework\Application;
use Pagekit\Extension\Extension;

class %CLASSNAME% extends Extension
{
    /**
     * {@inheritdoc}
     */
    public function boot(Application $app)
    {
        parent::boot($app);

        // your code here...
    }
}
