<?php

namespace Pagekit\System\Package\Exception;

class PackageNotFoundException extends ExtensionLoadException
{
}
