<?php

namespace Pagekit\System\Package\Exception;

class InvalidNameException extends ExtensionLoadException
{
}
