<?php

namespace Pagekit\System\Package\Exception;

class ExtensionLoadException extends \Exception
{
}
