require(['system!linkpicker'], function(system) {

    system.linkpicker('[name="widget[settings][redirect.login]"]');
    system.linkpicker('[name="widget[settings][redirect.logout]"]');

});